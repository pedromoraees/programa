import { Text, View, StyleSheet, Image } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
       <Text style={styles.titulo}>
        LeTurismo
      </Text>
     
  <Image style={styles.brava} source={require("./brava.jpg")}/>
  <Image style={styles.campeche} source={require("./campeche.jpg")}/>
  <Image style={styles.ingleses} source={require("./ingleses.jpg")}/>
  <Image style={styles.jurere} source={require("./jurere.jfif")}/>
  <Image style={styles.joaquina} source={require("./joaquina.jfif")}/>
  <Image style={styles.daniela} source={require("./daniela.jfif")}/>
  <Image style={styles.pedras} source={require("./pedras.jfif")}/>
  <Image style={styles.morro} source={require("./morro.jpg")}/>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

  brava: {
 
  width: 100,
  height: 100,
  left: 260,
  top: 120,

  },

  praiabrava:{

  left: 270,
  top: 120,
  },

campeche:{

  width: 100,
  height: 100,
 
  },

  praiacampeche: {

  right: 10,
  bottom: 240,
  },

ingleses:{

  width: 100,
  height: 100,
  left: 260,
  top: 10,
  },

  praiaingleses:{

   left: 260,
  top: 135,
  },

jurere: {

  width: 100,
  height: 100,
  bottom: 90,
},

praiajurere: {

bottom:190,
right:2,
},

joaquina:{

 width: 100,
  height: 100,
  left: 260,
  bottom: 80,

},

praiajoaquina: {

left: 260,
  top: 145,

},

daniela: {

  width: 100,
  height: 100,
  bottom: 160,
},

pedras: {

width: 100,
  height: 100,
  left: 260,
  bottom: 140,
},

praiapedras: {

bottom: 135,
left: 255,

},

morro: {

  width: 100,
  height: 100,
  bottom: 235,
},



  titulo: {

    margin: 2,
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    top: 50,

  },
});
