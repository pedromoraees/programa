import { Text, View, StyleSheet, Image } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
     
      <Image style={styles.foto} source={require("./logo.png")}/>

       <Text style={styles.titulo}>

      LeTurismo 
      
       </Text>
      
      <Text style={styles.texto}>

      As praias são destinos incríveis para relaxar e aproveitar o sol e o mar. Com suas areias douradas, águas cristalinas e brisa refrescante, elas proporcionam momentos de tranquilidade.
      
       </Text>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  foto: {
    margin: 10,
    width: 255,
    height: 255,
    left: 24,
    alignItems: 'center',
    justifyContent: 'center',
    resizeMode: "contain",
    },

      titulo: {
    margin: 24,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'center',
  },

      texto: {
    fontWeight: 'normal',
    FontSize: 30,

      }

});
