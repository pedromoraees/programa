import { Text, View, StyleSheet, TextInput, Image,TouchableOpacity, onPress  } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      
 <Image style={styles.logo} source={require("./logo.png")}/>


      <Text style={styles.titulo}>
        LeTurismo
      </Text>


      <Text style={styles.sub}>
 Crie sua conta para agendar suas viagens!
      </Text>

      <TextInput style={styles.barra}  
  placeholder=" Nome" />

   <TextInput style={styles.barra}  
  placeholder=" E-mail" />

 <TextInput style={styles.barra}  
  placeholder=" Data de Nascimento" />

 <TextInput style={styles.barra}  
  placeholder=" CPF" />

<TouchableOpacity style={styles.botao} onPress={onPress}>
  <Text style={styles.login}>Criar</Text>
</TouchableOpacity>
    
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

  titulo: {

    margin: 2,
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    bottom: 30,

  },

  barra:{

height: 40,
width: 300,
backgroundColor:'#ffff',
borderWidth:2,
margin:6,
},

sub: {

margin: 9,

},

logo: {

width: 100,
height: 100,
bottom: 50,
},

login: {

  color:'#fff',
fontSize: 22,
textAlign:'center',
},

botao: {


backgroundColor:'black',
width: 310,
alignItems: 'center',
padding: 10,
borderBottomLeftRadius: 10,
borderBottomRightRadius: 10,
borderTopLeftRadius: 10,
borderTopRightRadius: 10,
top: 10,

},

});
